///
/// @file
/// Declares macros for the facter library version.
///
#pragma once

///
/// The facter library major version.
///
#define LIBFACTER_VERSION_MAJOR 3
///
/// The facter library minor version.
///
#define LIBFACTER_VERSION_MINOR 2
///
/// The facter library patch version.
///
#define LIBFACTER_VERSION_PATCH 0

///
/// The facter library version as a string (without commit SHA1).
///
#define LIBFACTER_VERSION "3.2.0"

///
/// The facter library version as a string (with commit SHA1).
///
#define LIBFACTER_VERSION_WITH_COMMIT "3.2.0 (commit f69c92150765f4a3dad15c9ad5bc161597a57e1c)"
