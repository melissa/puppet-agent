/**
 * @file
 * Utility header for including Windows API headers.
 */
#pragma once

// Windows has several header files with fixed dependency ordering. Include interdependent headers here,
// and anywhere we need include this header.
#include <winsock2.h>
#include <windows.h>
